package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Novel
import com.example.data.NovelRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NovelViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: NovelRepository

    val novelsState: StateFlow<List<Novel>>

    init {
        val database = AppDatabase.getDatabase(application)
        val novelDao = database.novelDao()
        repository = NovelRepository(novelDao)
        
        novelsState = repository.allNovels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun addNovel(title: String, totalChapters: Int, currentChapter: Int) {
        viewModelScope.launch {
            val validChapters = totalChapters.coerceAtLeast(1)
            val validCurrent = currentChapter.coerceIn(0, validChapters)
            val novel = Novel(
                title = title.trim(),
                totalChapters = validChapters,
                currentChapter = validCurrent,
                lastUpdated = System.currentTimeMillis()
            )
            repository.insert(novel)
        }
    }

    fun updateNovelDetails(novel: Novel, title: String, totalChapters: Int, currentChapter: Int) {
        viewModelScope.launch {
            val validChapters = totalChapters.coerceAtLeast(1)
            val validCurrent = currentChapter.coerceIn(0, validChapters)
            val updated = novel.copy(
                title = title.trim(),
                totalChapters = validChapters,
                currentChapter = validCurrent,
                lastUpdated = System.currentTimeMillis()
            )
            repository.update(updated)
        }
    }

    fun incrementChapter(novel: Novel) {
        viewModelScope.launch {
            if (novel.currentChapter < novel.totalChapters) {
                val updated = novel.copy(
                    currentChapter = novel.currentChapter + 1,
                    lastUpdated = System.currentTimeMillis()
                )
                repository.update(updated)
            }
        }
    }

    fun decrementChapter(novel: Novel) {
        viewModelScope.launch {
            if (novel.currentChapter > 0) {
                val updated = novel.copy(
                    currentChapter = novel.currentChapter - 1,
                    lastUpdated = System.currentTimeMillis()
                )
                repository.update(updated)
            }
        }
    }

    fun deleteNovel(novel: Novel) {
        viewModelScope.launch {
            repository.delete(novel)
        }
    }
}
