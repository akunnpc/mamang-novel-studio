package com.example.data

import kotlinx.coroutines.flow.Flow

class NovelRepository(private val novelDao: NovelDao) {
    val allNovels: Flow<List<Novel>> = novelDao.getAllNovels()

    suspend fun insert(novel: Novel) {
        novelDao.insertNovel(novel)
    }

    suspend fun update(novel: Novel) {
        novelDao.updateNovel(novel)
    }

    suspend fun delete(novel: Novel) {
        novelDao.deleteNovel(novel)
    }
}
