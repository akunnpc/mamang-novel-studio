package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.Novel
import com.example.data.Character
import com.example.data.Chapter
import android.content.Context
import android.content.Intent
import kotlin.math.roundToInt

sealed class Screen {
    object List : Screen()
    data class Dashboard(val novelId: Int) : Screen()
    data class SubMenu(val novelId: Int, val menuName: String, val menuIcon: String) : Screen()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovelStudioApp(
    viewModel: NovelViewModel,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit
) {
    val novels by viewModel.novelsState.collectAsStateWithLifecycle()
    var currentScreen by remember { mutableStateOf<Screen>(Screen.List) }
    
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedNovelForDetail by remember { mutableStateOf<Novel?>(null) }
    
    // Safety check: if active novel in dashboard/submenu gets deleted or database is wiped, go back to list
    val activeNovel = when (val screen = currentScreen) {
        is Screen.Dashboard -> novels.find { it.id == screen.novelId }
        is Screen.SubMenu -> novels.find { it.id == screen.novelId }
        else -> null
    }
    
    LaunchedEffect(activeNovel, currentScreen) {
        if (activeNovel == null && currentScreen !is Screen.List) {
            currentScreen = Screen.List
        }
    }

    val activeDetailNovel = selectedNovelForDetail?.let { current ->
        novels.find { it.id == current.id }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (val screen = currentScreen) {
                                is Screen.List -> "Mamang Novel Studio"
                                is Screen.Dashboard -> activeNovel?.title ?: "Dashboard Novel"
                                is Screen.SubMenu -> screen.menuName
                            },
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.headlineMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = when (currentScreen) {
                                is Screen.List -> "Ruang Kreatif Karya Tulis Anda"
                                is Screen.Dashboard -> "Studio Utama Penulisan"
                                is Screen.SubMenu -> "Detail Fitur Studio"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                        )
                    }
                },
                navigationIcon = {
                    if (currentScreen !is Screen.List) {
                        IconButton(
                            onClick = {
                                currentScreen = when (val screen = currentScreen) {
                                    is Screen.SubMenu -> Screen.Dashboard(screen.novelId)
                                    else -> Screen.List
                                }
                            },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Kembali"
                            )
                        }
                    }
                },
                actions = {
                    if (currentScreen is Screen.Dashboard && activeNovel != null) {
                        // Settings / edit button for the novel directly in top bar of Dashboard!
                        IconButton(
                            onClick = { selectedNovelForDetail = activeNovel },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Pengaturan Novel",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier
                            .testTag("theme_toggle_button")
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Ganti Tema",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp)
                )
            )
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentScreen,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            transitionSpec = {
                val isGoingBack = targetState is Screen.List || 
                                 (targetState is Screen.Dashboard && initialState is Screen.SubMenu)
                
                if (isGoingBack) {
                    slideInHorizontally(
                        initialOffsetX = { -it },
                        animationSpec = spring()
                    ) togetherWith slideOutHorizontally(
                        targetOffsetX = { it },
                        animationSpec = spring()
                    )
                } else {
                    slideInHorizontally(
                        initialOffsetX = { it },
                        animationSpec = spring()
                    ) togetherWith slideOutHorizontally(
                        targetOffsetX = { -it },
                        animationSpec = spring()
                    )
                }
            },
            label = "screen_transition"
        ) { targetScreen ->
            when (targetScreen) {
                is Screen.List -> {
                    NovelListContent(
                        novels = novels,
                        onAddClick = { showAddDialog = true },
                        onNovelClick = { novel ->
                            currentScreen = Screen.Dashboard(novel.id)
                        },
                        onIncrement = { viewModel.incrementChapter(it) },
                        onDecrement = { viewModel.decrementChapter(it) }
                    )
                }
                is Screen.Dashboard -> {
                    if (activeNovel != null) {
                        NovelDashboardContent(
                            novel = activeNovel,
                            onMenuClick = { menuName, menuIcon ->
                                currentScreen = Screen.SubMenu(activeNovel.id, menuName, menuIcon)
                            },
                            onIncrement = { viewModel.incrementChapter(activeNovel) },
                            onDecrement = { viewModel.decrementChapter(activeNovel) }
                        )
                    }
                }
                is Screen.SubMenu -> {
                    if (activeNovel != null) {
                        when (targetScreen.menuName) {
                            "Character" -> {
                                CharacterSubMenuContent(
                                    novel = activeNovel,
                                    viewModel = viewModel,
                                    onBackClick = {
                                        currentScreen = Screen.Dashboard(targetScreen.novelId)
                                    }
                                )
                            }
                            "Chapter" -> {
                                ChapterSubMenuContent(
                                    novel = activeNovel,
                                    viewModel = viewModel,
                                    onBackClick = {
                                        currentScreen = Screen.Dashboard(targetScreen.novelId)
                                    }
                                )
                            }
                            else -> {
                                NovelSubMenuContent(
                                    novel = activeNovel,
                                    menuName = targetScreen.menuName,
                                    menuIcon = targetScreen.menuIcon,
                                    onBackClick = {
                                        currentScreen = Screen.Dashboard(targetScreen.novelId)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Novel Dialog
    if (showAddDialog) {
        AddNovelDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { title, total, current ->
                viewModel.addNovel(title, total, current)
                showAddDialog = false
            }
        )
    }

    // Detail & Edit Novel Dialog (Opened via "Buka")
    activeDetailNovel?.let { novel ->
        NovelDetailDialog(
            novel = novel,
            onDismiss = { selectedNovelForDetail = null },
            onUpdate = { title, total, current ->
                viewModel.updateNovelDetails(novel, title, total, current)
            },
            onDelete = {
                viewModel.deleteNovel(novel)
                selectedNovelForDetail = null
            },
            onIncrement = { viewModel.incrementChapter(novel) },
            onDecrement = { viewModel.decrementChapter(novel) }
        )
    }
}

@Composable
fun NovelListContent(
    novels: List<Novel>,
    onAddClick: () -> Unit,
    onNovelClick: (Novel) -> Unit,
    onIncrement: (Novel) -> Unit,
    onDecrement: (Novel) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Top control panel
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Kelola Studio",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "${novels.size} Total Novel Tersimpan",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                }
                
                Button(
                    onClick = onAddClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = CircleShape,
                    modifier = Modifier
                        .testTag("add_novel_button_top")
                        .minimumInteractiveComponentSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Tambah",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Tambah Novel",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Novel list or Empty State
        if (novels.isEmpty()) {
            EmptyStateView(onAddClick = onAddClick)
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(
                    items = novels,
                    key = { it.id }
                ) { novel ->
                    NovelCardItem(
                        novel = novel,
                        onOpenClick = { onNovelClick(novel) },
                        onIncrement = { onIncrement(novel) },
                        onDecrement = { onDecrement(novel) }
                    )
                }
            }
        }
    }
}

@Composable
fun NovelDashboardContent(
    novel: Novel,
    onMenuClick: (menuName: String, menuIcon: String) -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit
) {
    val progressAnim by animateFloatAsState(
        targetValue = novel.progressPercentage / 100f,
        animationSpec = spring(),
        label = "dashboard_progress"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Quick Stats banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Kemajuan Karya",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Chapter ${novel.currentChapter} dari ${novel.totalChapters}",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    
                    // Large percentage text
                    Text(
                        text = "${novel.progressPercentage.roundToInt()}%",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                LinearProgressIndicator(
                    progress = { progressAnim },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Quick adjustment inside dashboard
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Update Bab Cepat:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onDecrement,
                            enabled = novel.currentChapter > 0,
                            modifier = Modifier
                                .size(36.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Kurang", modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        IconButton(
                            onClick = onIncrement,
                            enabled = novel.currentChapter < novel.totalChapters,
                            modifier = Modifier
                                .size(36.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Tambah", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "Fitur & Studio Menulis",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Custom Grid
        val menuItems = listOf(
            MenuData("Chapter", "📖", "Kelola draf bab novel"),
            MenuData("Character", "👤", "Profil tokoh & karakter"),
            MenuData("World", "🌍", "Latar tempat & legenda"),
            MenuData("Timeline", "📅", "Alur & garis waktu"),
            MenuData("Ide", "📝", "Dapur coretan kreatif"),
            MenuData("AI Assistant", "🤖", "Diskusi ide dengan AI"),
            MenuData("Statistik", "📊", "Analisis progres & grafik")
        )
        
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            val rows = menuItems.chunked(2)
            items(rows) { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { item ->
                        DashboardMenuCard(
                            item = item,
                            modifier = Modifier.weight(1f),
                            onClick = { onMenuClick(item.title, item.emoji) }
                        )
                    }
                    if (rowItems.size < 2) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

data class MenuData(val title: String, val emoji: String, val description: String)

@Composable
fun DashboardMenuCard(
    item: MenuData,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(115.dp)
            .clickable { onClick() }
            .testTag("menu_card_${item.title.lowercase()}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // styled emoji container
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = item.emoji, fontSize = 18.sp)
                }
                
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
            }
            
            Column {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun NovelSubMenuContent(
    novel: Novel,
    menuName: String,
    menuIcon: String,
    onBackClick: () -> Unit
) {
    val featureDescription = when (menuName) {
        "Chapter" -> "Kelola bab-bab cerita Anda, susun bab draf, tulis naskah mentah, dan pantau jumlah kata karya tulisan Anda dengan rapi."
        "Character" -> "Petakan tokoh utama, tokoh pendamping, antagonis, buat biografi mendalam, visualisasi, serta deskripsikan hubungan antar watak."
        "World" -> "Bangun lore dunia cerita Anda secara mendetail meliputi geografi, sistem sihir/teknologi, peradaban, faksi, legenda kuno, dan aturan dunia."
        "Timeline" -> "Susun kronologi kejadian penting, alur cerita, kilas balik, garis waktu utama, agar petualangan karakter tetap logis dan seru."
        "Ide" -> "Tempat corat-coret ide spontan, cuplikan premis menarik, plot twist tidak terduga, atau kumpulan referensi sebelum terlupa."
        "AI Assistant" -> "Diskusikan perkembangan plot cerita, brainstorming ide orisinal, atau perbaiki kualitas dialog tokoh bersama asisten menulis cerdas Anda."
        "Statistik" -> "Analisis visual grafik penulisan kata Anda, hitung target harian, estimasi waktu rilis, serta grafik progress penyelesaian bab."
        else -> "Kelola detail novel Anda dengan nyaman secara lokal."
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Large visual indicator of the menu
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(text = menuIcon, fontSize = 54.sp)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Fitur $menuName",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = novel.title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            ),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Ruang $menuName Masih Kosong",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = featureDescription,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(
            onClick = onBackClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("submenu_back_button"),
            shape = CircleShape
        ) {
            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Kembali ke Dashboard", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun NovelCardItem(
    novel: Novel,
    onOpenClick: () -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit
) {
    val progressAnim by animateFloatAsState(
        targetValue = novel.progressPercentage / 100f,
        animationSpec = spring(),
        label = "progress"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("novel_card_${novel.id}")
            .clickable { onOpenClick() }, // Open Dashboard when card is pressed
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Buku",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = novel.title,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Chapter: ${novel.currentChapter} / ${novel.totalChapters}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 4.dp)
                ) {
                    IconButton(
                        onClick = onDecrement,
                        enabled = novel.currentChapter > 0,
                        modifier = Modifier
                            .size(32.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Kurang Chapter",
                            modifier = Modifier.size(16.dp),
                            tint = if (novel.currentChapter > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onIncrement,
                        enabled = novel.currentChapter < novel.totalChapters,
                        modifier = Modifier
                            .size(32.dp)
                            .background(
                                MaterialTheme.colorScheme.surfaceVariant,
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Tambah Chapter",
                            modifier = Modifier.size(16.dp),
                            tint = if (novel.currentChapter < novel.totalChapters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LinearProgressIndicator(
                    progress = { progressAnim },
                    modifier = Modifier
                        .weight(1f)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "${novel.progressPercentage.roundToInt()}%",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.width(42.dp),
                    textAlign = TextAlign.End
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onOpenClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("open_button_${novel.id}"),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.OpenInNew,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Buka Studio",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun EmptyStateView(onAddClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_novel_empty_1782876720903),
            contentDescription = "Belum ada novel",
            modifier = Modifier
                .size(220.dp)
                .clip(RoundedCornerShape(24.dp))
                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(24.dp)),
            contentScale = ContentScale.Crop
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Belum Ada Novel",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Mulai studio menulis Anda dengan mendaftarkan novel pertama Anda secara lokal sekarang.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = onAddClick,
            shape = CircleShape,
            modifier = Modifier.minimumInteractiveComponentSize()
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Daftarkan Novel Pertama", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddNovelDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, total: Int, current: Int) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var totalChaptersStr by remember { mutableStateOf("") }
    var currentChapterStr by remember { mutableStateOf("0") }
    
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Tambah Novel Baru",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Judul Novel") },
                    placeholder = { Text("Masukkan judul novel...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_title"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = totalChaptersStr,
                    onValueChange = { totalChaptersStr = it },
                    label = { Text("Total Chapter") },
                    placeholder = { Text("Contoh: 50") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_total_chapters"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = currentChapterStr,
                    onValueChange = { currentChapterStr = it },
                    label = { Text("Chapter Sekarang") },
                    placeholder = { Text("Contoh: 10") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_current_chapter"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                
                if (errorMsg != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Text("Batal")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val total = totalChaptersStr.toIntOrNull()
                            val current = currentChapterStr.toIntOrNull()
                            
                            when {
                                title.trim().isEmpty() -> {
                                    errorMsg = "Judul novel tidak boleh kosong!"
                                }
                                total == null || total <= 0 -> {
                                    errorMsg = "Total chapter harus angka lebih dari 0!"
                                }
                                current == null || current < 0 -> {
                                    errorMsg = "Chapter sekarang harus angka minimal 0!"
                                }
                                current > total -> {
                                    errorMsg = "Chapter sekarang tidak boleh melebihi total chapter!"
                                }
                                else -> {
                                    onConfirm(title, total, current)
                                }
                            }
                        },
                        shape = CircleShape,
                        modifier = Modifier
                            .testTag("save_novel_button")
                            .minimumInteractiveComponentSize()
                    ) {
                        Text("Simpan")
                    }
                }
            }
        }
    }
}

@Composable
fun NovelDetailDialog(
    novel: Novel,
    onDismiss: () -> Unit,
    onUpdate: (title: String, total: Int, current: Int) -> Unit,
    onDelete: () -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit
) {
    var isEditMode by remember { mutableStateOf(false) }
    
    var editTitle by remember { mutableStateOf(novel.title) }
    var editTotalStr by remember { mutableStateOf(novel.totalChapters.toString()) }
    var editCurrentStr by remember { mutableStateOf(novel.currentChapter.toString()) }
    
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(novel, isEditMode) {
        if (!isEditMode) {
            editTitle = novel.title
            editTotalStr = novel.totalChapters.toString()
            editCurrentStr = novel.currentChapter.toString()
            errorMsg = null
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            if (showDeleteConfirm) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Hapus Novel?",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Apakah Anda yakin ingin menghapus novel \"${novel.title}\"? Tindakan ini tidak dapat dibatalkan.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OutlinedButton(
                            onClick = { showDeleteConfirm = false },
                            shape = CircleShape,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Batal")
                        }
                        Button(
                            onClick = onDelete,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            shape = CircleShape,
                            modifier = Modifier
                                .testTag("delete_confirm_button")
                                .minimumInteractiveComponentSize()
                        ) {
                            Text("Hapus", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else if (isEditMode) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        text = "Edit Detail Novel",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Judul Novel") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    OutlinedTextField(
                        value = editTotalStr,
                        onValueChange = { editTotalStr = it },
                        label = { Text("Total Chapter") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    OutlinedTextField(
                        value = editCurrentStr,
                        onValueChange = { editCurrentStr = it },
                        label = { Text("Chapter Sekarang") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    
                    if (errorMsg != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMsg!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { isEditMode = false },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Batal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val total = editTotalStr.toIntOrNull()
                                val current = editCurrentStr.toIntOrNull()
                                
                                when {
                                    editTitle.trim().isEmpty() -> {
                                        errorMsg = "Judul novel tidak boleh kosong!"
                                    }
                                    total == null || total <= 0 -> {
                                        errorMsg = "Total chapter harus angka lebih dari 0!"
                                    }
                                    current == null || current < 0 -> {
                                        errorMsg = "Chapter sekarang harus angka minimal 0!"
                                    }
                                    current > total -> {
                                        errorMsg = "Chapter sekarang tidak boleh melebihi total chapter!"
                                    }
                                    else -> {
                                        onUpdate(editTitle, total, current)
                                        isEditMode = false
                                    }
                                }
                            },
                            shape = CircleShape,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Simpan Perubahan")
                        }
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Studio Detail",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        
                        Row {
                            IconButton(
                                onClick = { isEditMode = true },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(
                                onClick = { showDeleteConfirm = true },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Hapus",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = novel.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Progress Menulis / Membaca",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "${novel.progressPercentage.roundToInt()}%",
                                    fontSize = 44.sp,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text(
                                text = "Selesai: ${novel.currentChapter} dari ${novel.totalChapters} Chapter",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Sesuaikan Progress Cepat:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalButton(
                            onClick = onDecrement,
                            enabled = novel.currentChapter > 0,
                            modifier = Modifier
                                .height(56.dp)
                                .weight(1f),
                            shape = CircleShape
                        ) {
                            Icon(imageVector = Icons.Default.Remove, contentDescription = "Kurang")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Satu Bab", fontWeight = FontWeight.Bold)
                        }
                        
                        Spacer(modifier = Modifier.width(16.dp))
                        
                        Button(
                            onClick = onIncrement,
                            enabled = novel.currentChapter < novel.totalChapters,
                            modifier = Modifier
                                .height(56.dp)
                                .weight(1f),
                            shape = CircleShape
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Tambah")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Satu Bab", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = onDismiss,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    ) {
                        Text("Tutup Studio", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CharacterSubMenuContent(
    novel: Novel,
    viewModel: NovelViewModel,
    onBackClick: () -> Unit
) {
    val characters by viewModel.getCharactersForNovel(novel.id).collectAsStateWithLifecycle(initialValue = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedCharacterForDetail by remember { mutableStateOf<Character?>(null) }
    var selectedCharacterForEdit by remember { mutableStateOf<Character?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Character control panel
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Karakter Tokoh",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Text(
                        text = "${characters.size} Tokoh Terdaftar",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("add_character_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah Tokoh")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tambah Tokoh", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (characters.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👤", fontSize = 48.sp)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Belum Ada Tokoh",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Mulai bangun kedalaman kisah novel Anda dengan menambahkan karakter/tokoh pertama sekarang.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(characters, key = { it.id }) { character ->
                    CharacterCardItem(
                        character = character,
                        onClick = { selectedCharacterForDetail = character },
                        onEditClick = { selectedCharacterForEdit = character },
                        onDeleteClick = { viewModel.deleteCharacter(character) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Back to Dashboard button at the bottom
        OutlinedButton(
            onClick = onBackClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("character_back_button"),
            shape = CircleShape
        ) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Kembali ke Dashboard", fontWeight = FontWeight.Bold)
        }
    }

    if (showAddDialog) {
        AddEditCharacterDialog(
            title = "Tambah Tokoh Baru",
            onDismiss = { showAddDialog = false },
            onConfirm = { name, race, age, personality, description, skills, notes ->
                viewModel.addCharacter(
                    novelId = novel.id,
                    name = name,
                    race = race,
                    age = age,
                    personality = personality,
                    description = description,
                    skills = skills,
                    notes = notes
                )
                showAddDialog = false
            }
        )
    }

    selectedCharacterForEdit?.let { character ->
        AddEditCharacterDialog(
            title = "Edit Detail Tokoh",
            initialCharacter = character,
            onDismiss = { selectedCharacterForEdit = null },
            onConfirm = { name, race, age, personality, description, skills, notes ->
                viewModel.updateCharacter(
                    character = character,
                    name = name,
                    race = race,
                    age = age,
                    personality = personality,
                    description = description,
                    skills = skills,
                    notes = notes
                )
                selectedCharacterForEdit = null
            }
        )
    }

    selectedCharacterForDetail?.let { character ->
        CharacterDetailDialog(
            character = character,
            onDismiss = { selectedCharacterForDetail = null },
            onEditClick = {
                selectedCharacterForEdit = character
                selectedCharacterForDetail = null
            },
            onDeleteClick = {
                viewModel.deleteCharacter(character)
                selectedCharacterForDetail = null
            }
        )
    }
}

@Composable
fun CharacterCardItem(
    character: Character,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("character_card_${character.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👤", fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = character.name,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            CharacterTag(
                                text = character.race,
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            if (character.age.isNotEmpty()) {
                                CharacterTag(
                                    text = "Umur: ${character.age}",
                                    containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier.testTag("edit_char_${character.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Tokoh",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.testTag("delete_char_${character.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Hapus Tokoh",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            if (character.personality.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Sifat: ${character.personality}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (character.description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = character.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun CharacterTag(text: String, containerColor: Color, contentColor: Color) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(containerColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = contentColor
        )
    }
}

@Composable
fun AddEditCharacterDialog(
    title: String,
    initialCharacter: Character? = null,
    onDismiss: () -> Unit,
    onConfirm: (
        name: String,
        race: String,
        age: String,
        personality: String,
        description: String,
        skills: String,
        notes: String
    ) -> Unit
) {
    var name by remember { mutableStateOf(initialCharacter?.name ?: "") }
    var race by remember { mutableStateOf(initialCharacter?.race ?: "") }
    var age by remember { mutableStateOf(initialCharacter?.age ?: "") }
    var personality by remember { mutableStateOf(initialCharacter?.personality ?: "") }
    var description by remember { mutableStateOf(initialCharacter?.description ?: "") }
    var skills by remember { mutableStateOf(initialCharacter?.skills ?: "") }
    var notes by remember { mutableStateOf(initialCharacter?.notes ?: "") }

    var errorMsg by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nama Tokoh *") },
                        placeholder = { Text("Contoh: Pendekar Bayangan") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_char_name"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = race,
                            onValueChange = { race = it },
                            label = { Text("Ras / Suku") },
                            placeholder = { Text("Contoh: Manusia / Elf") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_char_race"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = age,
                            onValueChange = { age = it },
                            label = { Text("Umur") },
                            placeholder = { Text("Contoh: 25 / Abadi") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_char_age"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = personality,
                        onValueChange = { personality = it },
                        label = { Text("Sifat / Kepribadian") },
                        placeholder = { Text("Contoh: Dingin, Setia, Cerdas") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_char_personality"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Deskripsi Singkat") },
                        placeholder = { Text("Gambarkan penampilan atau perannya...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("input_char_description"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = skills,
                        onValueChange = { skills = it },
                        label = { Text("Kemampuan / Skill") },
                        placeholder = { Text("Contoh: Tapak Petir Tingkat 5") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_char_skills"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan Tambahan") },
                        placeholder = { Text("Rahasia latar belakang atau takdir karakter...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("input_char_notes"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                if (errorMsg != null) {
                    item {
                        Text(
                            text = errorMsg!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onDismiss,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Batal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (name.trim().isEmpty()) {
                                    errorMsg = "Nama tokoh wajib diisi!"
                                } else {
                                    onConfirm(
                                        name,
                                        race.ifBlank { "Manusia" },
                                        age,
                                        personality,
                                        description,
                                        skills,
                                        notes
                                    )
                                }
                            },
                            shape = CircleShape,
                            modifier = Modifier
                                .testTag("save_character_button")
                                .minimumInteractiveComponentSize()
                        ) {
                            Text("Simpan")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CharacterDetailDialog(
    character: Character,
    onDismiss: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            if (showDeleteConfirm) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Hapus Tokoh?",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Apakah Anda yakin ingin menghapus tokoh \"${character.name}\"? Tindakan ini tidak dapat dibatalkan.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OutlinedButton(
                            onClick = { showDeleteConfirm = false },
                            shape = CircleShape,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Batal")
                        }
                        Button(
                            onClick = onDeleteClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            shape = CircleShape,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Hapus", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("👤", fontSize = 28.sp)
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = character.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    CharacterTag(
                                        text = character.race,
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                    if (character.age.isNotEmpty()) {
                                        CharacterTag(
                                            text = "Umur: ${character.age}",
                                            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                            contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (character.personality.isNotEmpty()) {
                        item {
                            DetailSection(title = "Sifat & Kepribadian", content = character.personality)
                        }
                    }

                    if (character.description.isNotEmpty()) {
                        item {
                            DetailSection(title = "Deskripsi Fisik / Peran", content = character.description)
                        }
                    }

                    if (character.skills.isNotEmpty()) {
                        item {
                            DetailSection(title = "Kemampuan / Keahlian Khusus", content = character.skills)
                        }
                    }

                    if (character.notes.isNotEmpty()) {
                        item {
                            DetailSection(title = "Catatan Rahasia", content = character.notes)
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)))
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = { showDeleteConfirm = true },
                                modifier = Modifier.background(MaterialTheme.colorScheme.error.copy(alpha = 0.1f), CircleShape)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.error)
                            }
                            
                            Row {
                                OutlinedButton(
                                    onClick = onDismiss,
                                    shape = CircleShape
                                ) {
                                    Text("Tutup")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = onEditClick,
                                    shape = CircleShape
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailSection(title: String, content: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = content,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 20.sp
        )
    }
}

@Composable
fun ChapterSubMenuContent(
    novel: Novel,
    viewModel: NovelViewModel,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val chapters by viewModel.getChaptersForNovel(novel.id).collectAsStateWithLifecycle(initialValue = emptyList())
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedChapterForDetail by remember { mutableStateOf<Chapter?>(null) }
    var selectedChapterForEdit by remember { mutableStateOf<Chapter?>(null) }

    val totalWords = chapters.sumOf { it.wordCount }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Control panel / Summary card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Daftar Bab / Naskah",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "${chapters.size} Bab • $totalWords kata",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                        )
                    }

                    Button(
                        onClick = { showAddDialog = true },
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.testTag("add_chapter_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Tambah Bab")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bab Baru", fontWeight = FontWeight.Bold)
                    }
                }

                if (chapters.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)))
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    OutlinedButton(
                        onClick = {
                            shareAllChaptersAsTxt(context, novel.title, chapters)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_all_chapters_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Export Semua Chapter (.TXT)", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (chapters.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📖", fontSize = 48.sp)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Belum Ada Bab",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tulis bab pertama Anda sekarang! Bab akan otomatis diurutkan berurutan mulai dari Chapter 1.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(chapters, key = { it.id }) { chapter ->
                    ChapterCardItem(
                        chapter = chapter,
                        onClick = { selectedChapterForDetail = chapter },
                        onEditClick = { selectedChapterForEdit = chapter },
                        onDeleteClick = { viewModel.deleteChapter(chapter) },
                        onCopyClick = {
                            copyToClipboard(context, "${chapter.title}\n\n${chapter.content}")
                        },
                        onExportClick = {
                            shareChapterAsTxt(context, "Chapter ${chapter.chapterNumber}: ${chapter.title}", chapter.content)
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = onBackClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("chapter_back_button"),
            shape = CircleShape
        ) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Kembali ke Dashboard", fontWeight = FontWeight.Bold)
        }
    }

    if (showAddDialog) {
        val nextNum = chapters.size + 1
        AddEditChapterDialog(
            title = "Tambah Chapter $nextNum",
            onDismiss = { showAddDialog = false },
            onConfirm = { title, status, content, notes ->
                viewModel.addChapter(
                    novelId = novel.id,
                    title = title,
                    status = status,
                    content = content,
                    notes = notes
                )
                showAddDialog = false
            }
        )
    }

    selectedChapterForEdit?.let { chapter ->
        AddEditChapterDialog(
            title = "Edit Chapter ${chapter.chapterNumber}",
            initialChapter = chapter,
            onDismiss = { selectedChapterForEdit = null },
            onConfirm = { title, status, content, notes ->
                viewModel.updateChapter(
                    chapter = chapter,
                    title = title,
                    status = status,
                    content = content,
                    notes = notes
                )
                selectedChapterForEdit = null
            }
        )
    }

    selectedChapterForDetail?.let { chapter ->
        ChapterDetailDialog(
            chapter = chapter,
            onDismiss = { selectedChapterForDetail = null },
            onEditClick = {
                selectedChapterForEdit = chapter
                selectedChapterForDetail = null
            },
            onDeleteClick = {
                viewModel.deleteChapter(chapter)
                selectedChapterForDetail = null
            },
            onCopyClick = {
                copyToClipboard(context, "${chapter.title}\n\n${chapter.content}")
            },
            onExportClick = {
                shareChapterAsTxt(context, "Chapter ${chapter.chapterNumber}: ${chapter.title}", chapter.content)
            }
        )
    }
}

@Composable
fun ChapterCardItem(
    chapter: Chapter,
    onClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onCopyClick: () -> Unit,
    onExportClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("chapter_card_${chapter.id}"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${chapter.chapterNumber}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = chapter.title.ifBlank { "Tanpa Judul" },
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val statusColor = when (chapter.status) {
                                "Selesai" -> Color(0xFF2E7D32)
                                "Revisi" -> Color(0xFFEF6C00)
                                else -> Color(0xFF1565C0) // Draft
                            }
                            val statusBg = when (chapter.status) {
                                "Selesai" -> Color(0xFFE8F5E9)
                                "Revisi" -> Color(0xFFFFF3E0)
                                else -> Color(0xFFE3F2FD) // Draft
                            }
                            CharacterTag(
                                text = chapter.status,
                                containerColor = statusBg,
                                contentColor = statusColor
                            )
                            CharacterTag(
                                text = "${chapter.wordCount} kata",
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCopyClick,
                        modifier = Modifier.testTag("copy_chapter_${chapter.id}").size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Salin Konten",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onExportClick,
                        modifier = Modifier.testTag("export_chapter_${chapter.id}").size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Export ke TXT",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier.testTag("edit_chapter_${chapter.id}").size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Bab",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.testTag("delete_chapter_${chapter.id}").size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Hapus Bab",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            if (chapter.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Catatan: ${chapter.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (chapter.content.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = chapter.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun AddEditChapterDialog(
    title: String,
    initialChapter: Chapter? = null,
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        status: String,
        content: String,
        notes: String
    ) -> Unit
) {
    var chapterTitle by remember { mutableStateOf(initialChapter?.title ?: "") }
    var status by remember { mutableStateOf(initialChapter?.status ?: "Draft") }
    var content by remember { mutableStateOf(initialChapter?.content ?: "") }
    var notes by remember { mutableStateOf(initialChapter?.notes ?: "") }

    var errorMsg by remember { mutableStateOf<String?>(null) }
    
    val statusOptions = listOf("Draft", "Selesai", "Revisi")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                item {
                    OutlinedTextField(
                        value = chapterTitle,
                        onValueChange = { chapterTitle = it },
                        label = { Text("Judul Chapter *") },
                        placeholder = { Text("Contoh: Permulaan yang Baru") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_chapter_title"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                item {
                    Column {
                        Text(
                            text = "Status Bab",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            statusOptions.forEach { option ->
                                val isSelected = status == option
                                val containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                val contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(containerColor)
                                        .clickable { status = option }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = option,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = contentColor
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        label = { Text("Isi / Naskah Chapter *") },
                        placeholder = { Text("Tulis naskah cerita novel Anda di sini...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .testTag("input_chapter_content"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Catatan Singkat") },
                        placeholder = { Text("Contoh: Fokus ke dramatisasi adegan ini...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_chapter_notes"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                if (errorMsg != null) {
                    item {
                        Text(
                            text = errorMsg!!,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onDismiss,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Batal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (chapterTitle.trim().isEmpty()) {
                                    errorMsg = "Judul chapter wajib diisi!"
                                } else if (content.trim().isEmpty()) {
                                    errorMsg = "Isi naskah tidak boleh kosong!"
                                } else {
                                    onConfirm(
                                        chapterTitle,
                                        status,
                                        content,
                                        notes
                                    )
                                }
                            },
                            shape = CircleShape,
                            modifier = Modifier
                                .testTag("save_chapter_button")
                                .minimumInteractiveComponentSize()
                        ) {
                            Text("Simpan")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterDetailDialog(
    chapter: Chapter,
    onDismiss: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onCopyClick: () -> Unit,
    onExportClick: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            if (showDeleteConfirm) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Hapus Chapter?",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Apakah Anda yakin ingin menghapus \"Chapter ${chapter.chapterNumber}: ${chapter.title}\"? Bab selanjutnya akan bergeser otomatis urutannya.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        OutlinedButton(
                            onClick = { showDeleteConfirm = false },
                            shape = CircleShape,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Batal")
                        }
                        Button(
                            onClick = onDeleteClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            shape = CircleShape,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Hapus", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${chapter.chapterNumber}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = chapter.title.ifBlank { "Tanpa Judul" },
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    val statusColor = when (chapter.status) {
                                        "Selesai" -> Color(0xFF2E7D32)
                                        "Revisi" -> Color(0xFFEF6C00)
                                        else -> Color(0xFF1565C0)
                                    }
                                    val statusBg = when (chapter.status) {
                                        "Selesai" -> Color(0xFFE8F5E9)
                                        "Revisi" -> Color(0xFFFFF3E0)
                                        else -> Color(0xFFE3F2FD)
                                    }
                                    CharacterTag(
                                        text = chapter.status,
                                        containerColor = statusBg,
                                        contentColor = statusColor
                                    )
                                    CharacterTag(
                                        text = "${chapter.wordCount} kata",
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                    }

                    if (chapter.notes.isNotEmpty()) {
                        item {
                            DetailSection(title = "Catatan Bab", content = chapter.notes)
                        }
                    }

                    item {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Isi Naskah",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                            ) {
                                Text(
                                    text = chapter.content,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 24.sp,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)))
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = { showDeleteConfirm = true },
                                    modifier = Modifier.background(MaterialTheme.colorScheme.error.copy(alpha = 0.1f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = MaterialTheme.colorScheme.error)
                                }
                                IconButton(
                                    onClick = onCopyClick,
                                    modifier = Modifier.background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f), CircleShape)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Salin", tint = MaterialTheme.colorScheme.secondary)
                                }
                                IconButton(
                                    onClick = onExportClick,
                                    modifier = Modifier.background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "Export ke TXT", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                            
                            Row {
                                OutlinedButton(
                                    onClick = onDismiss,
                                    shape = CircleShape
                                ) {
                                    Text("Tutup")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = onEditClick,
                                    shape = CircleShape
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun copyToClipboard(context: Context, text: String) {
    try {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val clip = android.content.ClipData.newPlainText("Chapter Content", text)
        clipboard.setPrimaryClip(clip)
        android.widget.Toast.makeText(context, "Konten berhasil disalin!", android.widget.Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Gagal menyalin: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

fun shareChapterAsTxt(context: Context, title: String, content: String) {
    try {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, "$title\n\n$content")
        }
        context.startActivity(Intent.createChooser(shareIntent, "Bagikan / Simpan Chapter"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Gagal export: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

fun shareAllChaptersAsTxt(context: Context, novelTitle: String, chapters: List<Chapter>) {
    try {
        val combinedText = buildString {
            append("NOVEL: $novelTitle\n")
            append("========================================\n\n")
            chapters.forEach { chapter ->
                append("Chapter ${chapter.chapterNumber}: ${chapter.title}\n")
                append("Status: ${chapter.status}\n")
                append("Jumlah Kata: ${chapter.wordCount} kata\n")
                append("----------------------------------------\n")
                append(chapter.content)
                append("\n\n========================================\n\n")
            }
        }
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Semua Chapter - $novelTitle")
            putExtra(Intent.EXTRA_TEXT, combinedText)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Bagikan Semua Chapter"))
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "Gagal export: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}
