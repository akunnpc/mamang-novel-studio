package com.example.data

import kotlinx.coroutines.flow.Flow

class NovelRepository(
    private val novelDao: NovelDao,
    private val characterDao: CharacterDao
) {
    val allNovels: Flow<List<Novel>> = novelDao.getAllNovels()

    suspend fun insert(novel: Novel) {
        novelDao.insertNovel(novel)
    }

    suspend fun update(novel: Novel) {
        novelDao.updateNovel(novel)
    }

    suspend fun delete(novel: Novel) {
        novelDao.deleteNovel(novel)
    }

    // Character operations
    fun getCharactersForNovel(novelId: Int): Flow<List<Character>> {
        return characterDao.getCharactersForNovel(novelId)
    }

    suspend fun insertCharacter(character: Character) {
        characterDao.insertCharacter(character)
    }

    suspend fun updateCharacter(character: Character) {
        characterDao.updateCharacter(character)
    }

    suspend fun deleteCharacter(character: Character) {
        characterDao.deleteCharacter(character)
    }
}
