package com.example.ui

import com.github.ljcamargo.llamacpp.Llama 
import com.example.llamacpp.Llama 
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Character
import com.example.data.Chapter
import com.example.data.Novel
import com.example.data.NovelRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive

class NovelViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: NovelRepository

    val novelsState: StateFlow<List<Novel>>

    init {
        val database = AppDatabase.getDatabase(application)
        val novelDao = database.novelDao()
        val characterDao = database.characterDao()
        val chapterDao = database.chapterDao()
        repository = NovelRepository(novelDao, characterDao, chapterDao)
        
        novelsState = repository.allNovels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun addNovel(title: String, totalChapters: Int, currentChapter: Int) {
        viewModelScope.launch {
            val validChapters = totalChapters.coerceAtLeast(1)
            val validCurrent = currentChapter.coerceIn(0, validChapters)
            val novel = Novel(
                title = title.trim(),
                totalChapters = validChapters,
                currentChapter = validCurrent,
                lastUpdated = System.currentTimeMillis()
            )
            repository.insert(novel)
        }
    }

    fun updateNovelDetails(novel: Novel, title: String, totalChapters: Int, currentChapter: Int) {
        viewModelScope.launch {
            val validChapters = totalChapters.coerceAtLeast(1)
            val validCurrent = currentChapter.coerceIn(0, validChapters)
            val updated = novel.copy(
                title = title.trim(),
                totalChapters = validChapters,
                currentChapter = validCurrent,
                lastUpdated = System.currentTimeMillis()
            )
            repository.update(updated)
        }
    }

    fun incrementChapter(novel: Novel) {
        viewModelScope.launch {
            if (novel.currentChapter < novel.totalChapters) {
                val updated = novel.copy(
                    currentChapter = novel.currentChapter + 1,
                    lastUpdated = System.currentTimeMillis()
                )
                repository.update(updated)
            }
        }
    }

    fun decrementChapter(novel: Novel) {
        viewModelScope.launch {
            if (novel.currentChapter > 0) {
                val updated = novel.copy(
                    currentChapter = novel.currentChapter - 1,
                    lastUpdated = System.currentTimeMillis()
                )
                repository.update(updated)
            }
        }
    }

    fun deleteNovel(novel: Novel) {
        viewModelScope.launch {
            repository.delete(novel)
        }
    }

    // Character CRUD operations
    fun getCharactersForNovel(novelId: Int): Flow<List<Character>> {
        return repository.getCharactersForNovel(novelId)
    }

    fun addCharacter(
        novelId: Int,
        name: String,
        race: String,
        age: String,
        personality: String,
        description: String,
        skills: String,
        notes: String
    ) {
        viewModelScope.launch {
            val character = Character(
                novelId = novelId,
                name = name.trim(),
                race = race.trim(),
                age = age.trim(),
                personality = personality.trim(),
                description = description.trim(),
                skills = skills.trim(),
                notes = notes.trim()
            )
            repository.insertCharacter(character)
        }
    }

    fun updateCharacter(
        character: Character,
        name: String,
        race: String,
        age: String,
        personality: String,
        description: String,
        skills: String,
        notes: String
    ) {
        viewModelScope.launch {
            val updated = character.copy(
                name = name.trim(),
                race = race.trim(),
                age = age.trim(),
                personality = personality.trim(),
                description = description.trim(),
                skills = skills.trim(),
                notes = notes.trim()
            )
            repository.updateCharacter(updated)
        }
    }

    fun deleteCharacter(character: Character) {
        viewModelScope.launch {
            repository.deleteCharacter(character)
        }
    }

    // Chapter CRUD operations
    fun getChaptersForNovel(novelId: Int): Flow<List<Chapter>> {
        return repository.getChaptersForNovel(novelId)
    }

    fun addChapter(
        novelId: Int,
        title: String,
        status: String,
        content: String,
        notes: String
    ) {
        viewModelScope.launch {
            val maxNum = repository.getMaxChapterNumber(novelId)
            val nextNum = maxNum + 1
            val wordCount = countWords(content)
            val chapter = Chapter(
                novelId = novelId,
                chapterNumber = nextNum,
                title = title.trim(),
                status = status,
                content = content,
                notes = notes.trim(),
                wordCount = wordCount
            )
            repository.insertChapter(chapter)
        }
    }

    fun updateChapter(
        chapter: Chapter,
        title: String,
        status: String,
        content: String,
        notes: String
    ) {
        viewModelScope.launch {
            val wordCount = countWords(content)
            val updated = chapter.copy(
                title = title.trim(),
                status = status,
                content = content,
                notes = notes.trim(),
                wordCount = wordCount
            )
            repository.updateChapter(updated)
        }
    }

    fun deleteChapter(chapter: Chapter) {
        viewModelScope.launch {
            repository.deleteChapter(chapter)
        }
    }

    private fun countWords(text: String): Int {
        if (text.isBlank()) return 0
        return text.trim().split("\\s+".toRegex()).size
    }

    // AI Settings / Local model persistent variables
    private val prefs = application.getSharedPreferences("ai_settings_prefs", Context.MODE_PRIVATE)

    private val _aiModelName = MutableStateFlow<String?>(prefs.getString("ai_model_name", null))
    val aiModelName = _aiModelName.asStateFlow()

    private val _aiModelUri = MutableStateFlow<String?>(prefs.getString("ai_model_uri", null))
    val aiModelUri = _aiModelUri.asStateFlow()

    private val _aiModelLoading = MutableStateFlow(false)
    val aiModelLoading = _aiModelLoading.asStateFlow()

    private val _aiModelLoaded = MutableStateFlow(false)
    val aiModelLoaded = _aiModelLoaded.asStateFlow()

    private val _aiModelError = MutableStateFlow<String?>(null)
    val aiModelError = _aiModelError.asStateFlow()

    // GGUF Metadata structure
    data class GgufMetadata(
        val version: Int,
        val tensorCount: Long,
        val kvCount: Long
    )

    private val _aiModelMetadata = MutableStateFlow<GgufMetadata?>(null)
    val aiModelMetadata = _aiModelMetadata.asStateFlow()

    init {
        // Auto load model on startup if already selected
        _aiModelUri.value?.let { savedUri ->
            loadModelFromFile(savedUri)
        }
    }

    fun loadModelFromFile(uriString: String) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _aiModelLoading.value = true
            _aiModelLoaded.value = false
            _aiModelError.value = null
            _aiModelMetadata.value = null

            try {
                val uri = android.net.Uri.parse(uriString)
                val contentResolver = getApplication<Application>().contentResolver
                
                // Read magic and metadata from stream
                contentResolver.openInputStream(uri).use { inputStream ->
                    if (inputStream == null) {
                        throw Exception("Gagal membuka file stream. Izin akses penyimpanan perangkat mungkin telah dicabut.")
                    }

                    val headerBytes = ByteArray(24)
                    val bytesRead = inputStream.read(headerBytes)
                    if (bytesRead < 24) {
                        throw Exception("File terlalu kecil atau rusak untuk format model GGUF llama.cpp.")
                    }

                    val buffer = java.nio.ByteBuffer.wrap(headerBytes).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    val magic = buffer.int
                    
                    // Magic bytes for GGUF: 'G' 'G' 'U' 'F' -> 0x46554747 in Little Endian
                    if (magic != 0x46554747) {
                        throw Exception("Header Magic salah. Format berkas ini bukan .gguf yang didukung llama.cpp.")
                    }

                    val version = buffer.int
                    if (version !in 1..3) {
                        throw Exception("Versi GGUF ($version) tidak didukung. Llama.cpp Android mendukung versi GGUF 1, 2, atau 3.")
                    }

                    val tensorCount = buffer.long
                    val kvCount = buffer.long

                    // Model successfully simulated in memory
                    _aiModelMetadata.value = GgufMetadata(version, tensorCount, kvCount)
                    _aiModelLoaded.value = true
                }
            } catch (e: Exception) {
                _aiModelError.value = e.message ?: "Kesalahan yang tidak diketahui saat membaca berkas model."
            } finally {
                _aiModelLoading.value = false
            }
        }
    }

    fun selectModel(name: String, uri: String) {
        prefs.edit()
            .putString("ai_model_name", name)
            .putString("ai_model_uri", uri)
            .apply()
        _aiModelName.value = name
        _aiModelUri.value = uri
        
        // Trigger loading when selected
        loadModelFromFile(uri)
    }

    fun clearModel() {
        prefs.edit()
            .remove("ai_model_name")
            .remove("ai_model_uri")
            .apply()
        _aiModelName.value = null
        _aiModelUri.value = null
        _aiModelLoaded.value = false
        _aiModelLoading.value = false
        _aiModelError.value = null
        _aiModelMetadata.value = null
    }

    // AI Test Foundations
    private val _aiTestPrompt = MutableStateFlow("")
    val aiTestPrompt = _aiTestPrompt.asStateFlow()

    private val _aiTestOutput = MutableStateFlow("")
    val aiTestOutput = _aiTestOutput.asStateFlow()

    private val _aiTestGenerating = MutableStateFlow(false)
    val aiTestGenerating = _aiTestGenerating.asStateFlow()

    private var generationJob: kotlinx.coroutines.Job? = null

    fun setAiTestPrompt(prompt: String) {
        _aiTestPrompt.value = prompt
    }

    fun startTestGeneration() {
        if (_aiTestGenerating.value) return
        val currentPrompt = _aiTestPrompt.value
        if (currentPrompt.isBlank()) {
            _aiTestOutput.value = "⚠️ Silakan masukkan prompt terlebih dahulu!"
            return
        }

        _aiTestGenerating.value = true
        _aiTestOutput.value = ""

        generationJob = viewModelScope.launch {
            try {
                _aiTestOutput.value = "🤖 Memulai inisialisasi sesi inference lokal...\n"
                kotlinx.coroutines.delay(800)
                
                if (!_aiModelLoaded.value) {
                    _aiTestOutput.value += "\n⚠️ PERINGATAN: Model GGUF belum dimuat ke memori! Jalankan 'Import Model' terlebih dahulu di menu AI Settings.\n\n"
                    _aiTestOutput.value += "Inference dihentikan secara aman karena tidak ada model aktif."
                    _aiTestGenerating.value = false
                    return@launch
                }

                _aiTestOutput.value += "📂 Model Aktif: ${_aiModelName.value}\n"
                _aiTestOutput.value += "⚙️ Memuat konteks llama.cpp (simulasi thread)... Kunci parameter terdeteksi.\n"
                _aiTestOutput.value += "--------------------------------------------------\n"
                kotlinx.coroutines.delay(1000)

                val words = "Halo! Ini adalah fondasi simulasi teks respons dari llama.cpp untuk prompt Anda:\n\n\"$currentPrompt\"\n\nArsitektur ViewModel dan UI saat ini sudah terhubung sepenuhnya secara reaktif. Pada tahap selanjutnya, input ini akan dipasangkan langsung ke fungsi JNI llama_eval() untuk memproses token secara real-time langsung di perangkat Anda!".split(" ")
                
                for (word in words) {
                    if (!isActive) break
                    _aiTestOutput.value += word + " "
                    kotlinx.coroutines.delay(150)
                }

                _aiTestOutput.value += "\n\n--------------------------------------------------\n🟢 Selesai (Simulated Inference Success)."
            } catch (e: Exception) {
                _aiTestOutput.value += "\n❌ Kesalahan: ${e.message}"
            } finally {
                _aiTestGenerating.value = false
            }
        }
    }

    fun stopTestGeneration() {
        generationJob?.cancel()
        _aiTestGenerating.value = false
        _aiTestOutput.value += "\n\n🛑 Proses pembuatan teks dihentikan oleh pengguna."
    }


    // 👇 TAMBAHIN FUNGSI INI DI BAWAHNYA
    fun generateAIResponse(prompt: String) {
    viewModelScope.launch {
        _aiTestGenerating.value = true
        try {
            if (!_aiModelLoaded.value) {
                _aiTestOutput.value = "⚠️ Model belum dimuat! Import dulu di AI Settings."
                return@launch
            }
            // 🔥 PANGGIL AI BENERAN
            val result = Llama.generate(prompt)
            _aiTestOutput.value = result
        } catch (e: Exception) {
            _aiTestOutput.value = "Error: ${e.message}"
        } finally {
            _aiTestGenerating.value = false
        }
    }
}
