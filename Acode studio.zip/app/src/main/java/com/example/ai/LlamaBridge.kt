package com.example.ai

object LlamaBridge {
    private var isLibraryLoaded = false

    init {
        isLibraryLoaded = try {
            System.loadLibrary("mamang_llama_jni")
            true
        } catch (e: UnsatisfiedLinkError) {
            false
        }
    }

    fun isNativeAvailable(): Boolean = isLibraryLoaded

    fun loadModel(modelPath: String, contextSize: Int = 1024, threads: Int = 4): Boolean {
        if (!isLibraryLoaded) return false
        return nativeLoadModel(modelPath, contextSize, threads)
    }

    fun generate(prompt: String, maxTokens: Int = 128): String {
        if (!isLibraryLoaded) return "[ERROR] Native library tidak dimuat."
        return nativeGenerate(prompt, maxTokens)
    }

    fun freeModel() {
        if (isLibraryLoaded) nativeFreeModel()
    }

    private external fun nativeLoadModel(modelPath: String, nCtx: Int, nThreads: Int): Boolean
    private external fun nativeGenerate(prompt: String, maxTokens: Int): String
    private external fun nativeFreeModel()
}