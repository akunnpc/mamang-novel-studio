package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "novels")
data class Novel(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val totalChapters: Int,
    val currentChapter: Int,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val progressPercentage: Float
        get() = if (totalChapters > 0) {
            (currentChapter.toFloat() / totalChapters.toFloat() * 100f).coerceIn(0f, 100f)
        } else {
            0f
        }
}
