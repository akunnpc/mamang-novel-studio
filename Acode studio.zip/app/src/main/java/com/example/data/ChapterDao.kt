package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE novelId = :novelId ORDER BY chapterNumber ASC")
    fun getChaptersForNovel(novelId: Int): Flow<List<Chapter>>

    @Query("SELECT MAX(chapterNumber) FROM chapters WHERE novelId = :novelId")
    suspend fun getMaxChapterNumber(novelId: Int): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: Chapter)

    @Update
    suspend fun updateChapter(chapter: Chapter)

    @Delete
    suspend fun deleteChapter(chapter: Chapter)

    @Query("UPDATE chapters SET chapterNumber = chapterNumber - 1 WHERE novelId = :novelId AND chapterNumber > :deletedNum")
    suspend fun shiftChapterNumbersDown(novelId: Int, deletedNum: Int)
}
