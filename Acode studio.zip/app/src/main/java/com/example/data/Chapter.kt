package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "chapters",
    foreignKeys = [
        ForeignKey(
            entity = Novel::class,
            parentColumns = ["id"],
            childColumns = ["novelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["novelId"])]
)
data class Chapter(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val novelId: Int,
    val chapterNumber: Int, // Automatic ordering sequence (e.g. 1, 2, 3...)
    val title: String,
    val status: String, // "Draft", "Selesai", "Revisi"
    val content: String,
    val notes: String,
    val wordCount: Int
)
