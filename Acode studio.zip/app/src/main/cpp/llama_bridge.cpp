// llama_bridge.cpp
// Minimal JNI bridge between Kotlin (NovelViewModel) and llama.cpp.
// Exposes: load model, generate text, free model.

#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include "llama.h"

#define LOG_TAG "MamangLlamaBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_ai_LlamaBridge_nativeLoadModel(
        JNIEnv* env, jobject /* this */, jstring modelPath, jint nCtx, jint nThreads) {

    const char* path = env->GetStringUTFChars(modelPath, nullptr);
    LOGI("Loading model from: %s", path);

    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = 0;

    g_model = llama_load_model_from_file(path, model_params);
    env->ReleaseStringUTFChars(modelPath, path);

    if (g_model == nullptr) {
        LOGE("Failed to load model");
        return JNI_FALSE;
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = nCtx > 0 ? nCtx : 1024;
    ctx_params.n_threads = nThreads > 0 ? nThreads : 4;
    ctx_params.n_threads_batch = ctx_params.n_threads;

    g_ctx = llama_new_context_with_model(g_model, ctx_params);
    if (g_ctx == nullptr) {
        LOGE("Failed to create context");
        llama_free_model(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    LOGI("Model loaded successfully. n_ctx=%d n_threads=%d", ctx_params.n_ctx, ctx_params.n_threads);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_ai_LlamaBridge_nativeGenerate(
        JNIEnv* env, jobject /* this */, jstring prompt, jint maxTokens) {

    if (g_model == nullptr || g_ctx == nullptr) {
        return env->NewStringUTF("[ERROR] Model belum dimuat.");
    }

    const char* promptChars = env->GetStringUTFChars(prompt, nullptr);
    std::string promptStr(promptChars);
    env->ReleaseStringUTFChars(prompt, promptChars);

    const llama_vocab* vocab = llama_model_get_vocab(g_model);

    const int nPromptTokens = -llama_tokenize(vocab, promptStr.c_str(), promptStr.size(),
                                               nullptr, 0, true, true);
    std::vector<llama_token> tokens(nPromptTokens);
    llama_tokenize(vocab, promptStr.c_str(), promptStr.size(),
                   tokens.data(), tokens.size(), true, true);

    llama_batch batch = llama_batch_get_one(tokens.data(), tokens.size());

    std::string result;
    int nGenerated = 0;
    const int limit = maxTokens > 0 ? maxTokens : 128;

    while (nGenerated < limit) {
        if (llama_decode(g_ctx, batch) != 0) {
            LOGE("llama_decode failed");
            break;
        }

        auto* logits = llama_get_logits_ith(g_ctx, batch.n_tokens - 1);
        const int nVocab = llama_vocab_n_tokens(vocab);

        llama_token bestToken = 0;
        float bestLogit = logits[0];
        for (int i = 1; i < nVocab; i++) {
            if (logits[i] > bestLogit) {
                bestLogit = logits[i];
                bestToken = i;
            }
        }

        if (llama_vocab_is_eog(vocab, bestToken)) {
            break;
        }

        char buf[128];
        int n = llama_token_to_piece(vocab, bestToken, buf, sizeof(buf), 0, true);
        if (n > 0) {
            result.append(buf, n);
        }

        batch = llama_batch_get_one(&bestToken, 1);
        nGenerated++;
    }

    return env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_ai_LlamaBridge_nativeFreeModel(JNIEnv* env, jobject /* this */) {
    if (g_ctx != nullptr) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model != nullptr) {
        llama_free_model(g_model);
        g_model = nullptr;
    }
    LOGI("Model freed");
}